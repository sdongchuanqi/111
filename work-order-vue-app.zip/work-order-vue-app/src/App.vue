<template>
  <router-view />
</template>

<script setup>
</script>

<style>
  body { background: #f7f8fa; }
</style>
